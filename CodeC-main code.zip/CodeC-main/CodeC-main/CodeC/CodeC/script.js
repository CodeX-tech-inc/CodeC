const typedTextSpan = document.querySelector(".typed-text");
const textArray = ["UI/UX Designer", "Developer"];
const cursor = document.getElementById("cursor")
let textArrayIndex = 0;
let charIndex = 0;

function type() {
    if (charIndex < textArray[textArrayIndex].length) {
        typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
        charIndex++;
        setTimeout(type, 50); // Adjust typing speed here (milliseconds)
    } else {
        setTimeout(erase, 1500); // Wait before erasing
    }
}

function erase() {
    if (charIndex > 0) {
        typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, 30); // Adjust erasing speed here
    } else {
        textArrayIndex++;
        if (textArrayIndex >= textArray.length) {
            textArrayIndex = 0; // Reset to the beginning
        }
        setTimeout(type, 500); // Wait before typing the next phrase
    }
}

document.addEventListener("DOMContentLoaded", function() { // On DOM Load
    if (textArray.length) setTimeout(type, 500);
});

// Register user
document.getElementById("register-form").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
  
    fetch("/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ username, email, password })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert("User registered successfully!");
      } else {
        alert("Registration failed!");
      }
    });
  });
  
  // Login user
  document.getElementById("login-form").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;
  
    fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert("Login successful!");
      } else {
        alert("Login failed!");
      }
    });
  });
  
    const result = await response.json();

    if (result.success) {
        window.location.href = '/dashboard';  // Redirect on success
    } else {
        document.getElementById('error-message').innerText = result.message;
    }



document.addEventListener("DOMContentLoaded", () => {
    const flipCards = document.querySelectorAll(".flip-card");

    flipCards.forEach(card => {
        const learnMoreBtn = card.querySelector(".learn-more-btn");

        // Flip the card when clicking the "Learn More" button
        learnMoreBtn.addEventListener("click", (event) => {
            event.stopPropagation();
            card.setAttribute("data-flipped", "true");
        });

        // Automatically flip back when leaving the card area
        card.addEventListener("mouseleave", () => {
            card.setAttribute("data-flipped", "false");
        });
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const progressCircles = document.querySelectorAll(".progress-circle");

    const animateCircles = () => {
        progressCircles.forEach(circle => {
            const percentage = circle.getAttribute("data-percentage");
            // Set the pink gradient based on the percentage
            circle.style.background = `conic-gradient(#ff3385 ${percentage}%, #e0e0e0 ${percentage}%)`;
        });
    };

    const isVisible = (el) => {
        const rect = el.getBoundingClientRect();
        return rect.top >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight);
    };

    const onScroll = () => {
        progressCircles.forEach(circle => {
            if (isVisible(circle)) {
                animateCircles();
            }
        });
    };

    window.addEventListener("scroll", onScroll);
    onScroll(); // Trigger on load
});

